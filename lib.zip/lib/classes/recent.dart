// To parse this JSON data, do
//
//     final recent = recentFromJson(jsonString);

import 'dart:convert';

Recent recentFromJson(String str) => Recent.fromJson(json.decode(str));

String recentToJson(Recent data) => json.encode(data.toJson());

class Recent {
  Recent({
    this.cover,
    this.title,
    this.date,
    this.vidId,
  });

  String cover;
  String title;
  String date;
  String vidId;

  factory Recent.fromJson(Map<String, dynamic> json) => Recent(
        cover: json["cover"],
        title: json["title"],
        date: json["date"],
        vidId: json["vid_id"],
      );

  Map<String, dynamic> toJson() => {
        "cover": cover,
        "title": title,
        "date": date,
        "vid_id": vidId,
      };
  static List<Recent> parseRecent(List<dynamic> data) {
    List<Recent> entries = List<Recent>();

    data.forEach((element) => entries.add(Recent.fromJson(element)));

    return entries;
  }
}
