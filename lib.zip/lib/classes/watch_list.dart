// To parse this JSON data, do
//
//     final getWatchlist = getWatchlistFromJson(jsonString);

import 'dart:convert';

GetWatchlist getWatchlistFromJson(String str) =>
    GetWatchlist.fromJson(json.decode(str));

String getWatchlistToJson(GetWatchlist data) => json.encode(data.toJson());

class GetWatchlist {
  GetWatchlist({
    this.id,
    this.title,
    this.thumbnail,
    this.movie,
    this.rating,
    this.categories,
    this.status,
    this.duration,
    this.releasedate,
    this.budget,
    this.overview,
    this.images,
    this.trailer,
    this.keywords,
    this.payment,
    this.price,
    this.whouploaded,
    this.uploadstatus,
  });

  String id;
  String title;
  String thumbnail;
  String movie;
  String rating;
  String categories;
  String status;
  String duration;
  DateTime releasedate;
  String budget;
  String overview;
  String images;
  String trailer;
  String keywords;
  String payment;
  String price;
  dynamic whouploaded;
  String uploadstatus;

  factory GetWatchlist.fromJson(Map<String, dynamic> json) => GetWatchlist(
        id: json["id"],
        title: json["title"],
        thumbnail: json["thumbnail"],
        movie: json["movie"],
        rating: json["rating"],
        categories: json["categories"],
        status: json["status"],
        duration: json["duration"],
        releasedate: DateTime.parse(json["releasedate"]),
        budget: json["budget"],
        overview: json["overview"],
        images: json["images"],
        trailer: json["trailer"],
        keywords: json["keywords"],
        payment: json["payment"],
        price: json["price"],
        whouploaded: json["whouploaded"],
        uploadstatus: json["uploadstatus"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "thumbnail": thumbnail,
        "movie": movie,
        "rating": rating,
        "categories": categories,
        "status": status,
        "duration": duration,
        "releasedate":
            "${releasedate.year.toString().padLeft(4, '0')}-${releasedate.month.toString().padLeft(2, '0')}-${releasedate.day.toString().padLeft(2, '0')}",
        "budget": budget,
        "overview": overview,
        "images": images,
        "trailer": trailer,
        "keywords": keywords,
        "payment": payment,
        "price": price,
        "whouploaded": whouploaded,
        "uploadstatus": uploadstatus,
      };
  static List<GetWatchlist> parseRecent(List<dynamic> data) {
    List<GetWatchlist> entries = List<GetWatchlist>();

    data.forEach((element) => entries.add(GetWatchlist.fromJson(element)));

    return entries;
  }
}
