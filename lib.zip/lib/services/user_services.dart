// import 'package:dio/dio.dart';

// class UsersServices {
//   static String url = 'https://niiflicks.com/niiflicks/apis/user/getuserdata';
//   Dio _dio;
//   UsersServices() {
//     _dio = Dio();
//   }
//   Future fetchUserData() async {
//     try {
//       Response response = await http
//     } catch (e) {}
//   }
// }
