import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Messages extends StatefulWidget {
  Messages({Key key}) : super(key: key);

  @override
  _MessagesState createState() => _MessagesState();
}

class _MessagesState extends State<Messages> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('chats/zYpdHmgqkNpAt7jG7RYx/messages')
            .snapshots(),
        builder: (BuildContext context, chatSnapshot) {
          if (chatSnapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else {
            final chatdocs = chatSnapshot.data.documents;
            return ListView.builder(
                itemCount: chatSnapshot.data.documents.length,
                itemBuilder: (context, index) {
                  return Text(chatdocs[index]['text']);
                });
          }
        });
  }
}
