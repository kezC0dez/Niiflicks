import 'dart:convert' as convert;
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:livechatt/livechatt.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_paystack/flutter_paystack.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';
// import 'package:niiflicks/classes/get_views.dart';
// import 'package:niiflicks/classes/recent_detail.dart';
// import 'package:niiflicks/constant/color_const.dart';
// import 'package:niiflicks/utils/widgethelper/widget_helper.dart';
// import 'package:niiflicks/view/screens/chats_screen.dart';
// import 'package:niiflicks/view/screens/dashboard_screen.dart';
// import 'package:niiflicks/view/screens/live_chat.dart';
// import 'package:niiflicks/view/video/trailer.dart';
import 'package:niiflicks/view/video/video_apis.dart';
import 'package:niiflicks/view/video/video_player.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:progress_indicators/progress_indicators.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:startapp/startapp.dart';
import 'package:video_player/video_player.dart';

import 'package:niiflicks/model/movie.dart';
import 'package:niiflicks/components/body.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:http/http.dart' as http;

class RecentDetailsScreen extends StatefulWidget {
  // final Movie movie;

  // const RecentDetailsScreen({Key key, this.movie}) : super(key: key);
  final id;
  final date_produced;
  final cover;
  final title;

  RecentDetailsScreen({
    this.id,
    this.cover,
    this.date_produced,
    this.title,
  });
  @override
  _RecentDetailsScreenState createState() => _RecentDetailsScreenState();
}

class _RecentDetailsScreenState extends State<RecentDetailsScreen> {
  var publicKey = 'pk_test_6698ce224b9e7ccb65dd708d4c143103f3b353ee';
  Future<Map<String, dynamic>> _value;
  Future<Map<String, dynamic>> movieDetails() async {
    print('inside movie details');
    final prefs = await SharedPreferences.getInstance();
    var user_id = prefs.getString('userid');
    var vid_id = widget.id;
    var url = Uri.parse(
        'https://simplemovie.p.rapidapi.com/movie/info/videos/${vid_id}');
    var response = await http.get(url, headers: {
      'x-rapidapi-key': '54955f88e7mshdd4f9ff2678e1c8p19ce0djsnd6af5e47672f'
    });
    print('response:${response.statusCode}');
    if (response.statusCode == 200) {
      print(response.body);
      var jsonResponse =
          convert.jsonDecode(response.body) as Map<String, dynamic>;
      return jsonResponse;
    } else {
      print(response.body);
      throw Text('error data ',
          style: TextStyle(
            color: Colors.white,
          ));
    }
  }

  final _commentController = TextEditingController();
  Future addComments() async {
    String comments = _commentController.text;
    final prefs = await SharedPreferences.getInstance();
    var user_id = prefs.getString('userid');
    print(user_id);
    print(widget.id);
    print(comments);
    var url =
        Uri.parse('https://niiflicks.com/niiflicks/apis/user/addcomments');
    var data = {'comment': comments, 'userid': user_id, 'movieid': widget.id};
    final newUrl = url.replace(queryParameters: data);
    var response = await http.post(newUrl);
    if (response.statusCode == 200) {
      print(response.body);
    } else {
      print(response.body);
    }
  }

  // Future getComments() async {
  //   var url = 'https://niiflicks.com/niiflicks/apis/user/getcomments.php';
  //   var data = {
  //     'movieid':
  //   };
  // }

  final kInnerDecoration = BoxDecoration(
    color: Colors.transparent,
    border: Border.all(color: Colors.red),
    borderRadius: BorderRadius.circular(32),
  );

  // Future addGetViews() async {
  //   var data = {'movieid': widget.id};
  //   var url = Uri.parse('https://niiflicks.com/niiflicks/apis/movies/addviews');
  //   var response = await http.post(url, body: data);
  //   if (response.statusCode == 200) {
  //     print(response.body);
  //     print('you viewed this movie');
  //   } else {
  //     print(response.body);
  //     print('you did not view it');
  //   }
  // }

  VideoPlayerController _controller;

  final _paystackPlugin = PaystackPlugin();
  bool press = true;
  bool _available = false;
  final cols = Colors.transparent;
// var item = MediaItem(
//   id: 'assets/niiflicks.mp3',
//   album: 'Album name',
//   title: 'Track title',
// );
  String _getReference() {
    String platform;
    if (Platform.isIOS) {
      platform = 'iOS';
    } else {
      platform = 'Android';
    }

    return 'ChargedFrom${platform}_${DateTime.now().millisecondsSinceEpoch}';
  }

  // RewardedAd rewardedAd;
  // InterstitialAd interstitialAd;
  @override
  void initState() {
    // _createRewardedAd();
    // AudioService.playMediaItem(item);
    movieDetails();
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    super.initState();
    _controller = VideoPlayerController.network(widget.title)
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {});
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  
  @override
 
  int count;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: ListView(children: [
        Stack(children: [
          ClipPath(
            child: ClipRRect(
              child: CachedNetworkImage(
                  colorBlendMode: BlendMode.darken,
                  color: Colors.black54,
                  filterQuality: FilterQuality.high,
                  height: MediaQuery.of(context).size.height / 2,
                  width: double.infinity,
                  fit: BoxFit.fill,
                  imageUrl: widget.cover,
                  errorWidget: (context, url, error) => Container()),
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30)),
            ),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              leading: IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  }),
            ),
            FutureBuilder(
              future: movieDetails(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Container();
                } else if (snapshot.hasData) {
                  return Container(
                    padding: EdgeInsets.only(top: 120),
                    child: Center(
                      child: InkWell(
                        onTap: () {
                          StartApp.showInterstitialAd();
                        },
                        child: Column(
                          children: [
                            Stack(children: [
                              Container(
                                padding: EdgeInsets.only(bottom: 25, right: 24),
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.red[300],
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.white,
                                          offset: Offset(2.0, 2.0),
                                          blurRadius: 15.0,
                                          spreadRadius: 1.0),
                                      BoxShadow(
                                          color: Colors.red[200],
                                          offset: Offset(-4.0, -4.0),
                                          blurRadius: 15.0,
                                          spreadRadius: 1.0),
                                    ],
                                    gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          Colors.red[700],
                                          Colors.red[600],
                                          Colors.red[500],
                                          Colors.red[200],
                                        ],
                                        stops: [
                                          0,
                                          0.1,
                                          0.3,
                                          1
                                        ])),
                                child: IconButton(
                                  onPressed: () {
                                   StartApp.showInterstitialAd();
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: const Text(
                                          'Watch Ads to access Free Content'),
                                      backgroundColor: Colors.green,
                                      duration: const Duration(seconds: 20),
                                      action: SnackBarAction(
                                        label: '',
                                        onPressed: () {},
                                      ),
                                    ));
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                VideoPlayerScreenApi(
                                                    movie_stream: _available
                                                        ? 'N/A'
                                                        : '${snapshot.data['data'][0]['stream']}')));
                                  },
                                  icon: Icon(
                                    Icons.play_circle_outlined,
                                    color: Colors.red[900],
                                    size: 55,
                                  ),
                                ),
                              ),
                            ]),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 20, right: 10, left: 10),
                              child: Text(
                                "Watch movie".toUpperCase(),
                                style: TextStyle(
                                    fontFamily: 'Muli',
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                } else {
                  return Container();
                }
              },
            ),
            SizedBox(
              height: 160,
            ),
            // VideoPlayerScreen(controller:),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Overview',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.yellow,
                                  fontFamily: 'Muli'),
                              overflow: TextOverflow.ellipsis,
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  // Container(
                  //   height: 35,
                  //   child: Text(widget.id,
                  //       maxLines: 2,
                  //       overflow: TextOverflow.ellipsis,
                  //       style: TextStyle(
                  //           color: Colors.red,
                  //           fontFamily: 'Muil',
                  //           fontWeight: FontWeight.bold)),
                  // ),
                  FutureBuilder(
                    future: movieDetails(),
                    builder: (
                      context,
                      AsyncSnapshot snapshot,
                    ) {
                      if (!snapshot.hasData) {
                        return Center(
                          child: JumpingDotsProgressIndicator(
                            color: Colors.red,
                            fontSize: 30,
                          ),
                        );
                      } else if (snapshot.hasData) {
                        print("data sent: ${snapshot.data['description']}");
                        return Container(
                          height: 35,
                          child: Text(widget.title,
                              // _available
                              //     ? '${snapshot.data['data'][0]['description']}'
                              //     : 'N/A',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: Colors.red,
                                  fontFamily: 'Muil',
                                  fontWeight: FontWeight.bold)),
                        );
                      } else {
                        return CircularProgressIndicator();
                      }
                    },
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Release Date ',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                                fontFamily: 'Muli'),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Text(
                            widget.date_produced.toString(),
                            style: TextStyle(
                                color: Colors.yellow, fontFamily: 'Muli'),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Text(
                          //   'Run Time',
                          //   style: TextStyle(
                          //       fontWeight: FontWeight.bold,
                          //       color: Colors.red,
                          //       fontFamily: 'Muli'),
                          // ),
                          // SizedBox(
                          //   height: 5,
                          // ),
                          // Text(
                          //   'widget.durations',
                          //   style: TextStyle(
                          //       color: Colors.yellow, fontFamily: 'Muli'),
                          // ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),

            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 0, bottom: 10),
              child: Container(
                width: 410,
                height: 60,
                child: Card(
                  elevation: 7,
                  shadowColor: Colors.red,
                  color: Colors.grey[900],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(40),
                        bottomLeft: Radius.circular(40)),
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 28,
                      ),
                      Text(
                        'Ratings :',
                        style: TextStyle(color: Colors.red),
                      ),
                      RatingBar.builder(
                        initialRating: 1,
                        minRating: 1,
                        glowColor: Colors.red,
                        itemSize: 30,
                        glow: true,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        itemCount: 5,
                        itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                        itemBuilder: (context, _) => Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        onRatingUpdate: (rating) {
                          // sendRatings();
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Row(
                        children: [
                          Text(
                            '0',
                            style: TextStyle(color: Colors.red),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Icon(
                            Icons.star,
                            color: Colors.red,
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Center(
              child: Container(
                // decoration: kInnerDecoration,
                height: 50,
                width: 120,
                child: RaisedButton(
                  onPressed: () {
                    setState(() {
                      press = !press;
                    });
                  },
                  child: Column(
                    children: [
                      SizedBox(
                        height: 5,
                      ),
                      Icon(
                        Icons.thumb_down,
                        color: Colors.white,
                      ),
                      Text(
                        'Inapropriate',
                        style: TextStyle(color: Colors.white),
                      )
                    ],
                  ),
                  color: press ? Colors.red : cols,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(
                        color: Colors.red,
                      )),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),

            SizedBox(
              height: 30,
            ),
            // Container(
            //   height: 300,
            //   color: Colors.black,
            //   child: ListView(
            //     children: [
            //       Center(
            //         child: Text(
            //           'What do you think about this movie ${widget.title} ?',
            //           style: TextStyle(
            //               color: Colors.red, fontStyle: FontStyle.italic),
            //         ),
            //       ),
            //       Padding(
            //           padding:
            //               const EdgeInsets.only(left: 20, right: 20, top: 210),
            //           child: Stack(
            //             alignment: Alignment.centerRight,
            //             children: [
            //               TextField(
            //                   style: TextStyle(color: Colors.red),
            //                   keyboardType: TextInputType.text,
            //                   controller: _commentController,
            //                   obscureText: false,
            //                   decoration: InputDecoration(
            //                       enabled: true,
            //                       contentPadding: EdgeInsets.all(20),
            //                       // suffixIcon:
            //                       enabledBorder: OutlineInputBorder(
            //                         borderRadius: BorderRadius.circular(0),
            //                         borderSide: BorderSide(
            //                             color: Colors.red, width: 1.0),
            //                       ),
            //                       hintText: "Comments",
            //                       hintStyle: TextStyle(
            //                           color: Colors.red,
            //                           fontStyle: FontStyle.italic),
            //                       border: OutlineInputBorder())),
            //               IconButton(
            //                 onPressed: () {
            //                   addComments();
            //                   FocusScope.of(context).requestFocus(FocusNode());
            //                   // _commentController.clear();
            //                 },
            //                 icon: Icon(
            //                   Icons.send,
            //                   color: Colors.red[900],
            //                 ),
            //               ),
            //             ],
            //           ))
            //     ],
            //   ),
            // )
          ]),
        ]),
      ]),
    );
  }
}
