import 'chart.dart';
import 'album.dart';

class Home {
  final Chart chart;
  final List<Album> albums;

  Home({this.chart, this.albums});
}
