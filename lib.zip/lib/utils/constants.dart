import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const String kMethodChannel = 'music_player/songsUri';
const String kGetSongs = 'getSongs';

const String kPlaceholderPath = 'assets/images/placeholder.png';
const String kBalooBhainaFont = 'BalooBhaina';
Color kDefaultIControlsColor = Colors.blueGrey[800];
